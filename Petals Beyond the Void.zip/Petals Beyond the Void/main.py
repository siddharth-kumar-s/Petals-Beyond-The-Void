import pygame
import numpy as np
import math

#configuration
WIDTH, HEIGHT = 600, 600
MAX_ITER = 40

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Interactive Flowing Julia Fractal (Move Mouse | Space: Auto-Flow)")
clock = pygame.time.Clock()

x = np.linspace(-1.6, 1.6, WIDTH)
y = np.linspace(-1.6, 1.6, HEIGHT)
X, Y = np.meshgrid(x, y)
Z_BASE = X + 1j * Y

def generate_julia(c, max_iter):
    Z = Z_BASE.copy()
    escape_count = np.zero(Z.shape, dtype=np.float32)
    mask = np.ones(Z.shape, dtype=bool)

    for i in range(max_iter):
        Z[mask] = Z[mask] ** 2 + c
        escaped = np.abs(Z) > 2.0
        newly_escaped = escaped & mask
        escape_count[newly_escaped] = i
        mask &= ~escaped

        if not np.any(mask):
            break

    return escape_count

def apply_colormap(escape_count, max_iter, time_offset):
    norm = escape_count / max_iter

    r = (np.sin(norm * 6.28 + time_offset) * 127.5 + 127.5).astype(np.unit8)
    g = (np.sin(norm * 6.28 + time_offset + 2.09) * 127.5 + 127.5).astype(np.unit8)
    b = (np.sin(norm * 6.28 + time_offset + 4.18) * 127.5 + 127.5).astype(np.unit8)

    inside = (escape_count == 0)
    r[inside] = 0
    g[inside] = 0
    b[inside] = 0
    rgb = np.dstack((r, g, b))
    return np.transpose(rgb, (1, 0, 2))

runnig = True
auto_flow = False
angle = 0.0

while runnig:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            runnig = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                auto_flow = not auto_flow

    if auto_flow:
        angle += 0.03
        c = complex(0.7885 * math.cos(angle), 0.7885 * math.sin(angle))
    else:
        mx, my = pygame.mouse.get_pos()
        cx = (mx / WIDTH) * 3.0 - 1.5
        cy = (my / HIGHT) * 3.0 - 1.5
        c = complex(cx, cy)

    angle_color = p.time.get_ticks() * 0.002
    counts = generate_julia(c, MAX_ITER)
    rgb_array = apply_colormap(counts, MAX_ITER,angle_color)

    surf = pygame.surfarray.make_surface(rgb_array)
    screen.blit(surf, (0, 0))
    pygame.display.flip()

    clock.tick(60)

pygame.quit()                            